import re
import time
from datetime import date
from typing import TypedDict, Any
from langgraph.graph import StateGraph, START, END
from .config import settings
from .corpus import active_release
from .retrieval import retrieve_queries, citation, expand_graph, normalize_query, tokens
from .providers import privacy_gate, PrivacyBlocked, ProviderUnavailable, draft_and_verify, translate_checked, plan_queries
from .schemas import Question, Answer, Claim
from .models import AnswerTrace, PrivateDocument, uid
from sqlalchemy import select
from .security import digest
from .localization import localize_explanations

DISCLAIMERS={
 'en':'Information, not legal advice. Classification is provisional. Confirm requirements with the competent authority or a qualified IP facilitator.',
 'hi':'यह जानकारी है, कानूनी सलाह नहीं। वर्गीकरण प्रारंभिक है। संबंधित प्राधिकरण या योग्य बौद्धिक संपदा विशेषज्ञ से पुष्टि करें।',
 'mr':'ही माहिती आहे, कायदेशीर सल्ला नाही. वर्गीकरण प्राथमिक आहे. संबंधित प्राधिकरण किंवा पात्र बौद्धिक संपदा तज्ज्ञाकडून खात्री करा.'}
HEADINGS={'en':'Evidence from your selected jurisdiction','hi':'न्यायक्षेत्र के अनुसार स्रोत','mr':'निवडलेल्या अधिकारक्षेत्रातील स्रोत'}
PROMPT_VERSION='2026.09.2-rag'
UNSAFE=re.compile(r'(ignore (?:all |previous |the )?instructions|reveal.*system prompt|bypass.*(?:consent|paywall)|forge.*citation|fabricate.*(?:law|source)|make up.*(?:law|citation))',re.I)
CLINICAL=re.compile(r'(what dose|dosage for|treat my|cure my|diagnose me|मुझे.*खुराक|माझा.*डोस)',re.I)
DOMAIN=re.compile(r'(patent|trademark|trade mark|copyright|design|geographic|\bgi\b|plant|variet|trade secret|ayur|aahara|drug|cosmetic|formulat|biodivers|biological|\babs\b|nagoya|\bcbd\b|gratk|\bpct\b|madrid|hague|budapest|trips|traditional|knowledge|pharma|herbal|label|advert|export|licen|regulat|intellectual|\bip\b|food|नियम|कायदा|आयुर्वेद)',re.I)

class State(TypedDict,total=False):
    question: Question
    db: Any
    rows: list
    citations: list
    claims: list
    stages: list[str]
    limitations: list[str]
    metrics: dict
    blocked: bool
    generated: bool
    translation: str | None

def guard(state):
    question=state['question']; limitations=[]
    context=' '.join(question.previous_questions+[question.query])
    # With an LLM, unfamiliar wording is evaluated against evidence rather than a keyword whitelist.
    domain_missing=not DOMAIN.search(normalize_query(context)) and settings().generation_provider=='none'
    blocked=bool(UNSAFE.search(context) or CLINICAL.search(question.query) or domain_missing)
    if re.search(r'\b(?:ASU|medicine|nutraceutical)\b',question.query,re.I) and not UNSAFE.search(context) and not CLINICAL.search(question.query):blocked=False
    blocked=blocked or bool(re.search(r'(निर्देश.*(?:भूल|विसर)|कानून गढ़|कायदा बनवा|खुराक.*लेनी|तापासाठी.*डोस)',question.query))
    years=[int(y) for y in re.findall(r'\b(20\d{2})\b',question.query)]
    if years and max(years)>date.today().year:
        blocked=True
        limitations.append('The question refers to a future-dated authority that this corpus cannot verify.')
    if blocked: limitations.append('This assistant handles Ayurveda IP and regulatory information. It cannot provide clinical treatment, fabricated authority, or access-control bypasses.')
    return {'blocked':blocked,'limitations':limitations,'stages':['Scope and privacy check'],'claims':[],'rows':[],'citations':[],'metrics':{},'generated':False,'translation':None}

def search(state):
    q=state['question']
    if state['blocked']: return {}
    queries=[q.query]; limitations=list(state['limitations']); planned=False
    if settings().generation_provider!='none':
        try:
            privacy_gate('\n'.join(q.previous_questions+[q.query]),q.confidential,q.cloud_consent,bool(q.case_id))
            queries=plan_queries(q.query,q.jurisdiction,q.market,q.previous_questions)
            planned=True
        except (PrivacyBlocked,ProviderUnavailable) as error:
            limitations.append(str(error))
    elif q.previous_questions:
        queries.append(q.previous_questions[-1]+' '+q.query)
    rows,metrics=retrieve_queries(state['db'],queries,q.jurisdiction,q.market,q.as_of)
    rows,edges=expand_graph(state['db'],rows,q.jurisdiction,q.market,q.as_of)
    metrics['graph_edges']=len(edges)
    metrics['llm_query_planning']=planned
    return {'rows':rows,'citations':[citation(r) for r in rows],'metrics':metrics,'limitations':limitations,'stages':state['stages']+(['LLM search planning'] if planned else [])+['Jurisdiction-filtered hybrid retrieval','Evidence-backed graph lookup']}

def compose(state):
    if state['blocked'] or not state['citations']: return {}
    q=state['question']; sources=state['citations']; limitations=list(state['limitations'])
    approved=[c for c in sources if c.review_status=='approved' and not c.stale]
    evidence=sources if settings().reference_synthesis_enabled else approved
    claims=[]; generated=False; attempted=False; verification={}
    if settings().generation_provider!='none' and evidence:
        try:
            privacy_gate('\n'.join(q.previous_questions+[q.query]),q.confidential,q.cloud_consent,bool(q.case_id))
            attempted=True
            private_facts=[]
            if q.case_id and settings().generation_provider=='ollama':
                documents=state['db'].scalars(select(PrivateDocument).where(PrivateDocument.case_id==q.case_id).limit(4)).all()
                private_facts=[{'document_id':d.id,'text':d.text[:3000],'status':'user-provided facts, not legal authority'} for d in documents]
            claims=draft_and_verify(q.query,evidence,q.jurisdiction,q.market,private_facts=private_facts,previous_questions=q.previous_questions,diagnostics=verification)
            generated=bool(claims)
            if not claims: limitations.append('The generated answer could not be verified. No answer has been released. Use the source library or request facilitator review.')
        except (PrivacyBlocked,ProviderUnavailable) as error: limitations.append(str(error))
    elif settings().generation_provider!='none' and not approved:
        limitations.append('Current retrieved sources require applicability review before generated legal guidance can use them.')
    else: limitations.append('Generation is not configured. These are retrieved source excerpts, not a synthesized legal conclusion.')
    if not generated and not attempted:
        query_terms=set(tokens(normalize_query(q.query)))
        for source in sources[:4]:
            # Display only literal source spans: no fabricated extractive "answers".
            sentences=[s for s in re.split(r'(?<=[.;।])\s+|\n\n',source.excerpt) if len(s.strip())>=60 and len(s.split())>=8]
            sentences=[s for s in sentences if s.rstrip().endswith(('.', ';', '।'))]
            if re.search(r'\boral\b',q.query,re.I) and not re.search(r'\binject',q.query,re.I):
                sentences=[s for s in sentences if not re.search(r'\binjectable\b|\binjectables\b',s,re.I)]
            if not sentences: continue
            best=max(sentences,key=lambda s:len(set(tokens(s))&query_terms),default=source.excerpt)
            if len(best)>700: best=best[:700]
            claims.append({'text':best,'citation_ids':[source.id],'support_quote':best,'verification':'extractive'})
    if any(c.review_status!='approved' for c in sources):
        limitations.append('Reference-library material has not been approved as current legal guidance. Check amendments and applicability before relying on it.')
    if any(c.stale for c in sources): limitations.append('Some source checks are overdue; their current status is uncertain.')
    if generated and any(c.review_status!='approved' or c.stale for c in evidence):
        limitations.append('This is an AI synthesis of reference documents, not verified current-law guidance. Confirm applicability and amendments.')
    return {'claims':claims,'generated':generated,'limitations':limitations,'metrics':{**state['metrics'],'generation_attempted':attempted,'verification':verification},'stages':state['stages']+['Claim and citation validation']}

def translate(state):
    q=state['question']
    if q.language=='en' or not state['generated']: return {}
    if q.confidential or q.case_id:
        return {'limitations':state['limitations']+['Confidential answers are not sent to an external translation service. Original text is retained.']}
    try:
        translated=translate_checked('\n'.join(c['text'] for c in state['claims']),q.language,q.cloud_consent)
        return {'translation':translated,'stages':state['stages']+['Translation reference checks']}
    except (ProviderUnavailable,PrivacyBlocked) as error:
        return {'limitations':state['limitations']+[str(error)]}

builder=StateGraph(State)
builder.add_node('guard',guard);builder.add_node('retrieve',search);builder.add_node('compose',compose);builder.add_node('translate',translate)
builder.add_edge(START,'guard');builder.add_edge('guard','retrieve');builder.add_edge('retrieve','compose');builder.add_edge('compose','translate');builder.add_edge('translate',END)
workflow=builder.compile()

def answer_question(db,q:Question,session_id=None):
    start=time.perf_counter()
    state=workflow.invoke({'question':q,'db':db},{'recursion_limit':8})
    release=active_release(db); trace_id=uid()
    # Return only citations that actually occur in the released answer.
    cited={i for c in state['claims'] for i in c['citation_ids']}
    citations=[c for c in state['citations'] if c.id in cited]
    mode='generated' if state['generated'] else 'retrieval' if state['claims'] else 'abstention'
    fully_reviewed=all(c.review_status=='approved' and not c.stale for c in citations)
    status='supported' if state['generated'] and fully_reviewed else 'partial' if state['claims'] else 'insufficient'
    limitations=list(dict.fromkeys(s.strip() for s in state['limitations'] if isinstance(s,str) and s.strip()))
    if not state['claims'] and not state['blocked'] and not state['metrics'].get('generation_attempted'): limitations.append('Information not found in the current corpus for this jurisdiction. No legal conclusion has been generated.')
    if q.language!='en' and not state['translation']: limitations.append('Original source language is retained. Interface language does not imply that these excerpts are translated.')
    metrics={**state['metrics'],'elapsed_ms':round((time.perf_counter()-start)*1000),'generation_provider':settings().generation_provider,
             'generation_model':settings().gemini_model if settings().generation_provider=='gemini' else settings().ollama_model if settings().generation_provider=='ollama' else None}
    result=Answer(trace_id=trace_id,mode=mode,jurisdiction=q.jurisdiction,market=q.market,language=q.language,
        heading=HEADINGS[q.language] if mode!='abstention' else {'en':'More evidence is needed','hi':'अधिक साक्ष्य की आवश्यकता है','mr':'अधिक पुराव्याची आवश्यकता आहे'}[q.language],
        claims=[Claim(**c) for c in state['claims']],citations=citations,evidence_status=status,
        evidence_reasons=['AI synthesis linked to retrieved passages; entailment checked. '+('Source applicability reviewed.' if fully_reviewed else 'Source applicability remains unreviewed.') if state['generated'] else 'Literal excerpts available; applicability review required.' if state['claims'] else 'No sufficient evidence for a supported answer.'],
        limitations=limitations,next_steps=['Open the cited source and check its version.','Use the formulation or ABS assessment for product-specific routing.','Export your case or request facilitator review if uncertainty remains.'],
        disclaimer=DISCLAIMERS[q.language],corpus_release=release.id if release else None,translation=state['translation'],stages=state['stages'],metrics=metrics)
    db.add(AnswerTrace(id=trace_id,session_id=session_id,query_hash=digest(q.query),jurisdiction=q.jurisdiction,market=q.market,language=q.language,
        model=settings().generation_provider,prompt_version=PROMPT_VERSION,release_id=release.id if release else None,
        citation_ids=[c.id for c in citations],outcome=mode,metrics=metrics))
    db.commit()
    return Answer(**localize_explanations(result.model_dump(),q.language))

from pathlib import Path
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[2]

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / '.env', extra='ignore')
    app_env: str = 'development'
    database_url: str = f"sqlite:///{(ROOT / 'data' / 'pilot.db').as_posix()}"
    session_secret: str = 'development-only-change-before-deployment'
    public_origin: str = 'http://127.0.0.1:5173'
    cookie_secure: bool = False
    storage_dir: Path = ROOT / 'data'
    corpus_manifest: Path = ROOT / 'corpus' / 'manifest.json'
    generation_provider: str = 'none'
    gemini_api_key: str = ''
    gemini_model: str = 'gemini-3.6-flash'
    gemini_thinking_level: str = 'low'
    generation_timeout_seconds: int = 90
    ollama_base_url: str = 'http://localhost:11434'
    ollama_model: str = 'qwen3:8b'
    embeddings_enabled: bool = True
    reference_synthesis_enabled: bool = True
    embedding_model: str = 'intfloat/multilingual-e5-small'
    embedding_revision: str = '614241f622f53c4eeff9890bdc4f31cfecc418b3'
    bhashini_user_id: str = ''
    bhashini_api_key: str = ''
    bhashini_pipeline_id: str = ''
    bhashini_config_url: str = 'https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/getModelsPipeline'
    admin_email: str = ''
    admin_password: str = ''
    guest_retention_hours: int = 24
    case_retention_days: int = 90
    audit_retention_days: int = 365
    max_upload_mb: int = 15
    daily_request_limit: int = 100
    requests_per_minute: int = 20
    source_stale_days: int = 30

    def validate_deployment(self):
        if self.app_env == 'production':
            if len(self.session_secret) < 32 or self.session_secret.startswith('development') or 'replace-with' in self.session_secret:
                raise RuntimeError('Set a random SESSION_SECRET of at least 32 characters.')
            if not self.cookie_secure or not self.public_origin.startswith('https://'):
                raise RuntimeError('Production requires HTTPS PUBLIC_ORIGIN and COOKIE_SECURE=true.')
            if not self.database_url.startswith('postgresql'):
                raise RuntimeError('Production requires PostgreSQL.')

@lru_cache
def settings():
    return Settings()

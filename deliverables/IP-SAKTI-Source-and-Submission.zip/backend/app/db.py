from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from .config import settings

class Base(DeclarativeBase):
    pass

cfg = settings()
cfg.storage_dir.mkdir(parents=True, exist_ok=True)
engine = create_engine(cfg.database_url, pool_pre_ping=True,
                       connect_args={'check_same_thread': False} if cfg.database_url.startswith('sqlite') else {})
if cfg.database_url.startswith('sqlite'):
    @event.listens_for(engine, 'connect')
    def foreign_keys(connection, _):
        connection.execute('PRAGMA foreign_keys=ON')
SessionLocal = sessionmaker(engine, expire_on_commit=False)

def get_db():
    with SessionLocal() as db:
        yield db

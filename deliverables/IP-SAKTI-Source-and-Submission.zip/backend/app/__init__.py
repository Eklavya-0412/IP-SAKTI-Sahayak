"""IP-SAKTI Sahayak application."""

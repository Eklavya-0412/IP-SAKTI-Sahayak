"""Allowlisted acquisition, immutable snapshots and explicit corpus review."""
import hashlib
import ipaddress
import json
import re
import socket
from pathlib import Path
from urllib.parse import urlparse, urljoin
from datetime import timedelta
import httpx
from bs4 import BeautifulSoup
from pypdf import PdfReader
from sqlalchemy import select, update, text as sql
from .config import ROOT, settings
from .models import Source, SourceVersion, Chunk, CorpusRelease, GraphEdge, now

MAX_DOWNLOAD = 35 * 1024 * 1024
ALLOWED_HOSTS = {'www.wipo.int','wipo.int','www.wto.org','wto.org','www.cbd.int','cbd.int','absch.cbd.int',
 'indiacode.nic.in','www.indiacode.nic.in','ipindia.gov.in','www.ipindia.gov.in','cdsco.gov.in',
 'fssai.gov.in','www.fssai.gov.in','nbaindia.org','www.nbaindia.org','nbaindia.nic.in','www.nbaindia.nic.in',
 'plantauthority.gov.in','www.plantauthority.gov.in','www.meity.gov.in','meity.gov.in','www.fda.gov','www.ema.europa.eu',
 'www.gov.uk','www.legislation.gov.uk','eur-lex.europa.eu','pcimh.gov.in','www.pcimh.gov.in','ayush.gov.in',
 'www.tkdl.res.in','tkdl.res.in','api.sci.gov.in','main.sci.gov.in','www.nist.gov','genai.owasp.org',
 'upload.indiacode.nic.in','parivesh.nic.in','egazette.gov.in'}

def safe_url(url):
    parsed = urlparse(url)
    if parsed.scheme != 'https' or parsed.hostname not in ALLOWED_HOSTS or parsed.port not in (None,443) or parsed.username:
        raise ValueError('Source URL is outside the HTTPS publisher allowlist.')
    for item in socket.getaddrinfo(parsed.hostname, 443):
        if not ipaddress.ip_address(item[4][0]).is_global:
            raise ValueError('Publisher resolved to a non-public address.')

def download(url):
    with httpx.Client(timeout=45, follow_redirects=False, headers={'User-Agent':'IP-SAKTI-ResearchPilot/1.0 (source preservation; low volume)'}) as client:
        for _ in range(5):
            safe_url(url)
            with client.stream('GET', url) as response:
                if response.is_redirect:
                    url = urljoin(url, response.headers['location'])
                    continue
                response.raise_for_status()
                body = bytearray()
                for part in response.iter_bytes():
                    body.extend(part)
                    if len(body) > MAX_DOWNLOAD: raise ValueError('Source exceeds download limit.')
                return bytes(body), response.headers.get('content-type',''), url
    raise ValueError('Too many source redirects.')

def extract(path: Path, use_ocr=False):
    """Return page text and extraction evidence. OCR is opt-in and never repairs silently."""
    pages, sparse, ocr_pages = [], [], []
    if path.suffix.lower() == '.pdf':
        reader = PdfReader(path)
        if reader.is_encrypted and not reader.decrypt(''): raise ValueError('Password-protected PDF is not supported.')
        if len(reader.pages) > 1000: raise ValueError('PDF exceeds page limit.')
        for index, page in enumerate(reader.pages):
            raw = page.extract_text() or ''
            if len(raw.strip()) < 80:
                sparse.append(index+1)
                if use_ocr:
                    import pypdfium2, pytesseract
                    pdf = pypdfium2.PdfDocument(str(path))
                    raw = pytesseract.image_to_string(pdf[index].render(scale=2).to_pil(), lang='eng+hin+mar')
                    pdf.close()
                    ocr_pages.append(index+1)
            pages.append((index+1, raw))
    elif path.suffix.lower() in ('.html','.htm'):
        soup = BeautifulSoup(path.read_bytes(), 'html.parser')
        for node in soup(['script','style','nav','header','footer','form','noscript']): node.decompose()
        main = soup.find('main') or soup.find('article') or soup.body or soup
        pages = [(None, main.get_text('\n', strip=True))]
    else:
        pages = [(None, path.read_text(encoding='utf-8', errors='replace'))]
    # Preserve page text offsets; normalize only newline conventions.
    pages = [(p,t.replace('\r\n','\n').replace('\x00','')) for p,t in pages]
    damaged = sum(t.count('\ufffd') for _,t in pages)
    suspect = [p for p,t in pages if len(re.findall(r'(?<!\w)[A-Za-z](?!\w)',t))>150 or re.search(r'[\u1b00-\u1cff]',t)]
    return pages, {'pages':len(pages),'sparse_pages':sparse,'ocr_pages':ocr_pages,'replacement_characters':damaged,
        'suspect_glyph_pages':suspect,'requires_review':bool(sparse or damaged or suspect or not any(len(t.strip())>=60 for _,t in pages)),'method':'pypdf/bs4','expert_reviewed':False}

def reprocess_ocr(db,source_id):
    """Append recovered pages without modifying already-cited chunk identifiers."""
    from sqlalchemy import func
    import pypdfium2,pytesseract
    version=db.scalar(select(SourceVersion).where(SourceVersion.source_id==source_id).order_by(SourceVersion.retrieved_at.desc()))
    if not version: raise ValueError('Acquire the source first.')
    if version.review_status=='approved': raise ValueError('Approved extraction cannot be changed; use a curator-managed new release.')
    quality=dict(version.quality)
    pending=sorted((set(quality.get('sparse_pages',[]))|set(quality.get('suspect_glyph_pages',[])))-set(quality.get('ocr_pages',[])))
    ordinal=(db.scalar(select(func.max(Chunk.ordinal)).where(Chunk.version_id==version.id)) or 0)+1
    total=0
    pdf=pypdfium2.PdfDocument(version.path)
    try:
        for page in pending:
            raw=pytesseract.image_to_string(pdf[page-1].render(scale=2).to_pil(),lang='eng+hin+mar')
            for data in split_pages([(page,raw)]):
                data['ordinal']=ordinal;data['locator']='OCR · '+data['locator'];ordinal+=1
                db.add(Chunk(version_id=version.id,**data));total+=1
            quality['ocr_pages']=sorted(set(quality.get('ocr_pages',[])+[page]))
            quality['ocr_engine']='tesseract eng+hin+mar';quality['requires_review']=True
            version.quality=dict(quality);db.commit()
    finally:
        pdf.close()
    return {'recovered_chunks':total,'pages':pending,'expert_reviewed':False}

HEADING = re.compile(r'(?m)^\s*((?:SECTION|Section|Article|ARTICLE|Rule|RULE|CHAPTER|Chapter)\s+[\w.-]+[^\n]{0,180}|\d{1,3}[.][ \t]+[^\n]{3,150})')

def split_pages(pages):
    ordinal = 0
    for page, raw in pages:
        boundaries = [0] + [m.start() for m in HEADING.finditer(raw) if m.start()>0] + [len(raw)]
        heading = ''
        for start, end in zip(boundaries,boundaries[1:]):
            section = raw[start:end]
            match = HEADING.match(section)
            if match: heading = match.group(1).strip()
            cursor = start
            while cursor < end:
                limit = min(cursor+1800,end)
                if limit < end:
                    boundary = raw.rfind('\n',cursor+900,limit)
                    if boundary == -1: boundary = raw.rfind(' ',cursor+900,limit)
                    if boundary > cursor: limit = boundary
                excerpt = raw[cursor:limit]
                if len(excerpt.strip()) >= 60:
                    yield dict(ordinal=ordinal,heading=heading[:300],locator=heading[:300] or (f'PDF page {page}' if page else 'Official page excerpt'),
                               page=page,start_offset=cursor,end_offset=limit,text=excerpt)
                    ordinal += 1
                cursor = limit if limit > cursor else end

def load_manifest(db):
    manifest = json.loads(settings().corpus_manifest.read_text(encoding='utf-8'))
    for entry in manifest['sources']:
        source = db.get(Source, entry['id'])
        values = {k:entry[k] for k in ('title','publisher','url','jurisdiction','market','language','authority','category','access','notes') if k in entry}
        if not source:
            db.add(Source(id=entry['id'], disposition=entry.get('disposition','pending'), **values))
        else:
            for k,v in values.items(): setattr(source,k,v)
    db.commit()
    return manifest

def ingest(db, entry, use_ocr=False):
    source = db.get(Source,entry['id'])
    if entry.get('disposition') in ('excluded','pointer','background'):
        return {'status':'skipped','reason':entry.get('notes')}
    if entry.get('local_path'):
        origin = (ROOT / entry['local_path']).resolve()
        if not origin.is_relative_to((ROOT/'Resources').resolve()): raise ValueError('Local source must be in Resources.')
        body = origin.read_bytes()
        ext = origin.suffix.lower()
        resolved_url = entry['url']
    else:
        body, content_type, resolved_url = download(entry['url'])
        ext = '.pdf' if body.startswith(b'%PDF') else '.html'
    checksum = hashlib.sha256(body).hexdigest()
    source.checked_at = now()
    existing = db.scalar(select(SourceVersion).where(SourceVersion.source_id==source.id,SourceVersion.checksum==checksum))
    if existing:
        db.commit()
        return {'status':'unchanged','version_id':existing.id}
    folder = settings().storage_dir / 'snapshots' / source.id
    folder.mkdir(parents=True,exist_ok=True)
    path = folder / f'{checksum}{ext}'
    if not path.exists(): path.write_bytes(body)
    pages, quality = extract(path,use_ocr)
    quality['resolved_url'] = resolved_url
    quality['source_origin'] = 'user_supplied' if entry.get('local_path') else 'official_download'
    version = SourceVersion(source_id=source.id, checksum=checksum,path=str(path),quality=quality,
        effective_from=entry.get('effective_from'),publication_date=entry.get('publication_date'),
        review_status='pending', review_note='Awaiting extraction, applicability and provenance review.')
    db.add(version)
    db.flush()
    chunks = [Chunk(version_id=version.id,**data) for data in split_pages(pages)]
    db.add_all(chunks)
    source.disposition='review_required'
    db.commit()
    return {'status':'ingested','version_id':version.id,'chunks':len(chunks),'quality':quality}

def reference_release(db, name='Supplied reference library'):
    """Activate searchable references, explicitly NOT a legally approved release."""
    versions = db.scalars(select(SourceVersion).join(Source).where(Source.authority.notin_(['draft','statistics','notice']),SourceVersion.review_status=='pending')).all()
    ids = []
    for v in versions:
        if db.scalar(select(Chunk.id).where(Chunk.version_id==v.id).limit(1)):
            v.review_status='reference_only'
            v.review_note='Extraction available for source discovery. Legal applicability and expert review remain pending.'
            ids.append(v.id)
    old = db.scalar(select(CorpusRelease).where(CorpusRelease.active==True))
    if old:
        old.active=False
        ids = list(set(old.version_ids+ids))
    # Keep exactly one snapshot per source; older releases retain their own IDs.
    candidates=db.scalars(select(SourceVersion).where(SourceVersion.id.in_(ids)).order_by(SourceVersion.retrieved_at.desc())).all()
    latest={}
    for version in candidates: latest.setdefault(version.source_id,version.id)
    ids=list(latest.values())
    db.flush()
    release = CorpusRelease(name=name,version_ids=ids,active=True,review_note='Reference-only baseline. No expert sign-off claimed.')
    db.add(release)
    db.commit()
    return release

def active_release(db): return db.scalar(select(CorpusRelease).where(CorpusRelease.active==True))

def embed_chunks(db):
    from .retrieval import encoder
    model = encoder()
    if model is None: raise ValueError('Enable embeddings and pin a model revision first.')
    total = 0
    while True:
        rows = db.scalars(select(Chunk).where(Chunk.embedding.is_(None)).limit(32)).all()
        if not rows: break
        vectors = model.encode(['passage: '+c.heading+' '+c.text for c in rows],normalize_embeddings=True).tolist()
        for chunk,vector in zip(rows,vectors):
            chunk.embedding=vector
            if db.bind.dialect.name=='postgresql':
                db.execute(sql('UPDATE chunks SET vector_embedding=CAST(:v AS vector) WHERE id=:id'),{'v':json.dumps(vector),'id':chunk.id})
        db.commit()
        total+=len(rows)
    return total
